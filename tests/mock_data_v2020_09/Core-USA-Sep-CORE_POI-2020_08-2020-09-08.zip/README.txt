﻿Thank you for shopping at the SafeGraph Data Bar!

* DOCUMENTATION and DATA SCHEMAS are at https://docs.safegraph.com/docs

* If you need help parsing the JSON columns or using the data in ESRI, please see our FAQs at https://docs.safegraph.com/docs/faqs

* Let us know if you have any questions or issues by emailing us at support@safegraph.com

* Happy exploring!